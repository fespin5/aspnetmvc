﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Encuestas.Models;

namespace Encuestas.Controllers
{
    public class ReporteEncuestasBloqueController : Controller
    {
        //
        // GET: /ReporteEncuestasBloque/

        private EncuestasEntities db = new EncuestasEntities();

        public ActionResult Index()
        {
            ViewData["Encuestas"] = ListaSelectEncuestas(1);
            ViewData["Oficinas"] = ListaSelectOficinas(1);
            return View();
        }

        public ActionResult GenerarReporte(String entidadID, String encuestaID, String oficinaCOD = null)
        {
            Int16 entID = Convert.ToInt16(entidadID);
            Int16 encID = Convert.ToInt16(encuestaID);

            List<TabulacionXBloque_Result> resultado = null;

            var r = db.ReporteTabulacionXBloqueSP(entID, encID, oficinaCOD);

            resultado = r.ToList();

            

            return PartialView("ResultadoReporte",resultado);
        }

        public List<SelectListItem> ListaSelectEncuestas(Int16 entidadID)
        {
            List<SelectListItem> lista = null;

            var encuestas = db.Encuestas.ToList();

            var r = (from enc in encuestas where enc.EntidadID == entidadID
                     select new SelectListItem{Value = enc.EncuestaID.ToString(), Text = enc.Nombre}
                     ).ToList();
            lista = r;

            SelectListItem primerItem = new SelectListItem { Value = "-1", Text = "Seleccione una encuesta" };
            lista.Insert(0, primerItem);
            return lista;
        }

        public List<SelectListItem> ListaSelectOficinas(Int16 entidadID)
        {
            List<SelectListItem> lista = null;

            var oficinas = db.Oficinas.ToList();

            var r = (from ofi in oficinas
                     where ofi.EntidadID == entidadID
                     select new SelectListItem { Value = ofi.OficinaCOD, Text = ofi.Nombre }
                     ).ToList();
            lista = r;

            SelectListItem primerItem = new SelectListItem { Value = "-1", Text = "Seleccione una oficina" };
            lista.Insert(0, primerItem);
            return lista;
        }

    }
}
